function Input() {
    let input = prompt("Введите элементы числового массива через запятую:");
    
    if (input === null || input.trim() === "") {
        alert("Ввод отменен или пуст");
        return null;
    }
    let array = input.split(',').map(item => {
        let num = parseFloat(item.trim());
        return isNaN(num) ? 0 : num; // Заменяем некорректные значения на 0
    });
    return array;
}

function Sorted(array) {
    for (let i = 0; i < array.length - 1; i++) {
        if (array[i] < array[i + 1]) {
            return false;
        }
    }
    return true;
}

function FirstViolation(array) {
    for (let i = 0; i < array.length - 1; i++) {
        if (array[i] < array[i + 1]) {
            return i + 1;
        }
    }
    return -1;
}

function Reverse(array) {
    let reversed = [];
    for (let i = array.length - 1; i >= 0; i--) {
        reversed.push(array[i]);
    }
    return reversed;
}

function Process() {
    let array = Input();
    
    if (!array) {
        return;
    }
    let result;
    if (Sorted(array)) {
        let reversedArray = Reverse(array);
        result = "Массив упорядочен по убыванию.\n" +
                 "Исходный массив: [" + array.join(", ") + "]\n" +
                 "Массив в обратном порядке: [" + reversedArray.join(", ") + "]";
    } else {
        let violationIndex = FirstViolation(array);
        result = "Массив НЕ упорядочен по убыванию.\n" +
                 "Исходный массив: [" + array.join(", ") + "]\n" +
                 "Первый элемент, нарушающий упорядоченность: " + violationIndex + 
                 " (значение: " + array[violationIndex] + ")";
    }
    alert(result);
}
Process();