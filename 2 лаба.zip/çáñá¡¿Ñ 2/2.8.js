function Size() {
    let n;
    do {
        n = parseInt(prompt("Введите размерность квадратной матрицы (n):"));
        if (isNaN(n) || n <= 0) {
            alert("Пожалуйста, введите положительное целое число!");
        }
    }
    while (isNaN(n) || n <= 0);
    return n;
}

function Matrix(n) {
    const matrix = [];
    for (let i = 0; i < n; i++) {
        matrix[i] = [];
        for (let j = 0; j < n; j++) {
            let element;
            do {
                element = parseInt(prompt(`Введите элемент матрицы [${i}] [${j}]:`));
                if (isNaN(element)) {
                    alert("Пожалуйста, введите целое число!");
                }
            }
            while (isNaN(element));
            matrix[i][j] = element;
        }
    }
    return matrix;
}

function String(matrix) {
    let result = "";
    for (let i = 0; i < matrix.length; i++) {
        result += matrix[i].join(" ") + "\n";
    }
    return result;
}

function Process(matrix) {
    const n = matrix.length;
    const processedMatrix = [];
    
    for (let i = 0; i < n; i++) {
        processedMatrix[i] = [...matrix[i]];
    }
    
    for (let i = 0; i < n; i++) {
        const j = n - 1 - i;
        
        if (processedMatrix[i][j] >= 0) {
            processedMatrix[i][j] = 0;
        }
    }
    return processedMatrix;
}
function main() {
    alert("Замена неотрицательных элементов на побочной диагонали нулями");
    const n = Size();
    alert(`Теперь введите элементы матрицы:`);
    const originalMatrix = Matrix(n);
    alert("Исходная матрица:\n" + String(originalMatrix));
    const processedMatrix = Process(originalMatrix);
    alert("Обработанная матрица:\n" + 
          String(processedMatrix));
}
main();