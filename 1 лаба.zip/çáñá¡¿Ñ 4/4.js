function game() {
    const choices = ["камень", "ножницы", "бумага"];
    const win = {
        "камень": "ножницы",
        "ножницы": "бумага",
        "бумага": "камень"
    };

    while (true) {
        let user = prompt("Введите ваш выбор (камень, ножницы или бумага):").toLowerCase();
        const computer = choices[Math.floor(Math.random() * choices.length)];
        let result;
        
        if (user === computer) {
            result = `Ничья! Оба выбрали ${user}`;
        } else if (win[user] === computer) {
            result = `Вы победили! ${user} > ${computer}`;
        } else {
            result = `Компьютер победил! ${computer} > ${user}`;
        }

        alert(`Ваш выбор: ${user}\n
            Выбор компьютера: ${computer}\n
            ${result}`);

        const playAgain = confirm("Хотите сыграть еще раз?");
        
        if (!playAgain) {
            alert("Спасибо за игру!");
            break;
        }
    }
}
game();