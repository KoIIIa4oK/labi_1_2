let money = parseFloat(prompt("Введите сумму денег в кошельке:"));
let price = parseFloat(prompt("Введите цену одной шоколадки:"));
if (isNaN(money) || isNaN(price) || money < 0 || price <= 0) {
    alert("Пожалуйста, введите корректные положительные числа!");
}
else {
    let chocolates = Math.floor(money / price);
    let change = money - (chocolates * price);
    let result = `Вы можете купить ${chocolates} шоколадок\n`;
    result += `Ваша сдача: ${change.toFixed(2)} руб.`;
    alert(result);
}