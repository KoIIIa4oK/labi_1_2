let number = parseInt(prompt("Введите число:"));
if (isNaN(number)) {
    alert("Пожалуйста, введите корректное число!");
}
else {
    let divisors = [];
    for (let i = 1; i <= Math.abs(number); i++) {
        if (number % i === 0) {
            divisors.push(i);
        }
    }
    if (number < 0) {
        for (let i = -1; i >= number; i--) {
            if (number % i === 0) {
                divisors.push(i);
            }
        }
    }
    divisors.sort((a, b) => a - b);
    let result;
    if (divisors.length === 0) {
        result = "Число 0 не имеет делителей";
    } else {
        result = `Делители числа ${number}:\n${divisors.join(", ")}`;
    }
    alert(result);
}