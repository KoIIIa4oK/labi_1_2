let num1 = parseFloat(prompt("Введите первое число:"));
let num2 = parseFloat(prompt("Введите второе число:"));
let operator = prompt("Введите знак операции (+, -, *, /, %):");
let result;
let Valid = true;

if (operator === '+') {
    result = num1 + num2;
}
else if (operator === '-') {
    result = num1 - num2;
}
else if (operator === '*') {
    result = num1 * num2;
}
else if (operator === '/') {
    if (num2 !== 0) {
        result = num1 / num2;
    }
    else {
        alert("Ошибка: деление на ноль!");
        Valid = false;
    }
} else if (operator === '%') {
    if (num2 !== 0) {
        result = num1 % num2;
    }
    else {
        alert("Ошибка: деление на ноль!");
        Valid = false;
    }
}
else {
    alert("Ошибка: неверный знак операции!");
    Valid = false;
}

if (Valid) {
    alert(`${num1} ${operator} ${num2} = ${result}`);
}