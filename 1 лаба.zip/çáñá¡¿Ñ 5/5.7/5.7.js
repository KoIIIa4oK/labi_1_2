let number = prompt("Введите пятизначное число:");

if (number.length !== 5 || isNaN(number)) {
    alert("Пожалуйста, введите корректное пятизначное число!");
}
else {
    let num = parseInt(number);
    let lastDigit = num % 10;
    let firstFourDigits = Math.floor(num / 10);
    let newNumber = lastDigit * 10000 + firstFourDigits;
    alert(`Исходное число: ${number}\nНовое число: ${newNumber}`);
}