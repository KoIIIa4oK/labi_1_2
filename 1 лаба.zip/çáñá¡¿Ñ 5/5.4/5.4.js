let kilometers = prompt("Введите расстояние в километрах:");
if (kilometers === null) {
    alert("Отменено пользователем");
}
else if (kilometers === "" || isNaN(kilometers)) {
    alert("Пожалуйста, введите корректное число");
}
else {
    let miles = parseFloat(kilometers) * 0.621371;
    miles = miles.toFixed(2);
    alert(`${kilometers} км = ${miles} миль`);
}