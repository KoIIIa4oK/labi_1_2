let calculate = confirm("Введи любые два целых числа");
if (calculate){
    let x = prompt("Первое число: ");
    let y = prompt("Второе число: ");
    alert("Результат сложения: " + (parseInt(x) + parseInt(y)) + "\n"
        + "Результат вычитания: " + (parseInt(x) - parseInt(y)) + "\n"
        + "Результат умножения: " + (parseInt(x) * parseInt(y)) + "\n"
        + "Результат деления: " + (parseInt(x) / parseInt(y)) + "\n"
        + "Остаток от деления: " + (parseInt(x) % parseInt(y)));
}