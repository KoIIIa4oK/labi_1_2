let x = Math.floor(Math.random() * 100);
let y = NaN
let game = confirm("Твоя задача угадать целое число от 1 до 100, которое я загадал!");
if (game){
    while (y !== x) {  
        let y = prompt("Введи число: ");
        y = parseInt(y)
        if (y > x){
            alert("Слишком много!");
        }
        if (y < x){
            alert("Слишком мало!");
        }
        if (y == x){
            alert("Ты угадал! Загаданное число: " + y);
            break;
        }
    }
}